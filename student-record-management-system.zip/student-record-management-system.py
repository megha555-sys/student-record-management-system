# mysql connectivity 
import mysql.connector

# database connectivity steps
con = mysql.connector.connect(host="localhost", user="root", password="", database="college")

# add student function
def addStudent():
    id = input("Enter student id : ")
    name = input("Enter student name : ")
    city = input("Enter student city : ")
    email = input("Enter student email : ")
    pincode = input("Enter student pincode : ")
    course = input("Enter student course : ")
    percentage = input("Enter student percentage : ")

    data = (id, name, city, email,pincode,course,percentage)

    query = "insert into student values(%s, %s, %s, %s, %s, %s, %s)"
    c = con.cursor() 
    c.execute(query, data)
    con.commit()

    print("student registered successfully...")
    menu()

# updateStudent function
def updateStudent():
    c = con.cursor()

    query = "update student set name = %s, city = %s, email = %s,  pincode = %s,  course = %s ,  percentage = %s where id = %s"

    id = input("Enter the id of the student whose information to update : ")
    newName = input("Enter new name value : ")
    newCity = input("Enter new city value : ")
    newEmail = input("Enter new email value : ")
    newPincode = input("Enter new pincode value : ")
    newCourse = input("Enter new course value : ")
    newPercentage = input("Enter new Percentage value : ")

    c.execute(query, (newName, newCity, newEmail, newPincode, newCourse, newPercentage, id))
    

    con.commit()
    print("student information updated successfully...")
    menu()

# remove student 
def removeStudent():
    c = con.cursor()

    id = input("Enter the id of the student to remove : ")
    query = "delete from student where id = %s"
    c.execute(query, (id,))

    con.commit()
    print("student information  deleted successfully...")
    menu()
    
# display all student information
def displayStudent():
    c = con.cursor()

    query = "select * from student"
    c.execute(query)
    result = c.fetchall()

    for record in result:
        print("student id : ", record[0])
        print("student name : ", record[1])
        print("student City: ", record[2])
        print("student email : ", record[3])
        print("student pincode : ", record[4])
        print("student course : ", record[5])
        print("student percentage : ", record[6])
    
    menu()
    
# menu function to display student menu
def menu():
    print("Welcome to student record Management System")
    print("Choose from the options below : ")
    print("1. Add student ")       # insert
    print("2. Remove student ")    # delete
    print("3. Update student ")    # update
    print("4. Display All students ")  # select
    print("5. Exit ")

    choice = int(input("Enter your choice : "))
    if choice == 1:
        addStudent()
    elif choice == 2:
        removeStudent()
    elif choice == 3:
        updateStudent()
    elif choice == 4:
        displayStudent()
    elif choice == 5:
        exit(0)
    else:
        print("Invalid choice...!")
        menu()

menu()